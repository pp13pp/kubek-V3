const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>ESP8266 Control</title>
</head>
<body>
  <h2>Tryb LED: <span id="modeLabel">0</span> — <span id="modeName">PACIFICA</span></h2>
  <input type="range" id="modeSlider" min="0" max="10" value="0" oninput="updateLabel()" onchange="sendMode()">

  <h3>Temperatura: <span id="temp">?</span> °C</h3>
  <h3>Data i godzina ESP: <span id="espTime">?</span></h3>
  <h3>Naładowanie: <span id="soc">?</span>%</h3>

<script>
const modeNames = [
  "PACIFICA", "RAINBOW", "CYLON", "LAVA", "TWINKLE",
  "PULSEB", "PULSEG", "PULSER", "FIRE", "COLORWAVES", "BUBBLES"
];

function updateLabel() {
  let val = document.getElementById("modeSlider").value;
  document.getElementById("modeLabel").innerText = val;
  document.getElementById("modeName").innerText = modeNames[val] || "?";
}

function sendMode() {
  let mode = document.getElementById("modeSlider").value;
  fetch(`/setMode?mode=${mode}`);
}

function updateTemp() {
  fetch('/getTemp')
    .then(r => r.text())
    .then(t => document.getElementById("temp").innerText = t);
}

function updateEspTime() {
  fetch('/getTime')
    .then(r => r.text())
    .then(t => document.getElementById("espTime").innerText = t);
}

function updateSOC() {
  fetch('/getSOC')
    .then(r => r.text())
    .then(s => document.getElementById("soc").innerText = s);
}

window.onload = () => {
  const now = new Date();
  fetch(`/setTime?unix=${Math.floor(now.getTime() / 1000)}`);
  updateLabel(); updateTemp(); updateEspTime(); updateSOC();
};

setInterval(updateTemp, 5000);
setInterval(updateEspTime, 5000);
setInterval(updateSOC, 5000);
</script>
</body>
</html>
)rawliteral";
