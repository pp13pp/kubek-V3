const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>%TITLE%</title>
</head>
<body style="background:#111;color:#eee;font-family:Arial;text-align:center;padding:20px;">
<h1>%TITLE%</h1>
<p>If you see this, HTML is working!</p>
<div>
<input type="range" min="0" max="10" value="5" id="modeSlider" style="width:200px;">
</div>
<div id="modeName">Loading...</div>
<div>
<div>Temp: <span id="tempValue">--</span>°C</div>
<div>SOC: <span id="socValue">--</span>%</div>
</div>
<script>
console.log("Script loading...");
const s=document.getElementById("modeSlider");
const m=document.getElementById("modeName");

s.addEventListener("input",function(){
  console.log("Slider moved to:", s.value);
  fetch("/setMode?mode="+s.value)
    .then(function(r){return r.text();})
    .then(function(data){console.log("Set mode result:",data);})
    .catch(function(e){console.error("Set mode error:",e);});
});

function updateAll(){
  console.log("Updating data...");
  
  fetch("/getTemp")
    .then(function(r){return r.text();})
    .then(function(t){
      document.getElementById("tempValue").textContent=t;
      console.log("Temp:",t);
    })
    .catch(function(e){console.error("Temp error:",e);});
  
  fetch("/getSOC")
    .then(function(r){return r.text();})
    .then(function(s){
      document.getElementById("socValue").textContent=s;
      console.log("SOC:",s);
    })
    .catch(function(e){console.error("SOC error:",e);});
  
  fetch("/getModeName")
    .then(function(r){return r.text();})
    .then(function(n){
      m.textContent=n;
      console.log("Mode name:",n);
    })
    .catch(function(e){console.error("Mode name error:",e);});
}

console.log("Starting updates...");
updateAll();
setInterval(updateAll,5000);
</script>
</body>
</html>
)rawliteral";