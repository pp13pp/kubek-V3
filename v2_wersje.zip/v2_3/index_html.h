const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>%TITLE%</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      text-align: center;
      margin: 0; padding: 20px;
      background-color: #111; color: #eee;
    }
    h1 {
      margin-top: 10px;
      font-size: 24px;
    }
    .slider-container {
      margin: 30px auto 10px;
      width: 90%;
      max-width: 600px;
    }
    #modeSlider {
      -webkit-appearance: none;
      width: 100%;
      height: 50px; /* większy suwak */
      background: #333;
      border-radius: 12px;
      outline: none;
      cursor: pointer;
    }
    #modeSlider::-webkit-slider-thumb {
      -webkit-appearance: none;
      appearance: none;
      width: 40px;   /* większy "kciuk" */
      height: 50px;
      background: #0af;
      border-radius: 8px;
      cursor: pointer;
      margin-top: -9px; /* wyśrodkowanie pionowe */
      transition: background 0.3s ease;
    }
    #modeSlider::-moz-range-thumb {
      width: 40px;
      height: 50px;
      background: #0af;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    #modeSlider:hover::-webkit-slider-thumb {
      background: #08c;
    }
    .scale {
      display: flex;
      justify-content: space-between;
      margin: 10px 14px 0 14px; /* trochę mniejszy margines, bliżej suwaka */
      font-size: 14px;
      color: #aaa;
      user-select: none;
      letter-spacing: 1px;
      font-weight: 600;
    }
    #modeName {
      margin-top: 15px;
      font-weight: bold;
      font-size: 20px;
      color: #0af;
      min-height: 28px; /* żeby nie skakał tekst */
    }
    .status {
      margin-top: 25px;
      font-size: 18px;
    }
  </style>
</head>
<body>
  <h1>%TITLE%</h1>

  <div class="slider-container">
    <input type="range" min="0" max="12" value="0" id="modeSlider">
    <div class="scale">
      <span>0</span><span>2</span><span>4</span><span>6</span><span>8</span><span>10</span><span>12</span>
    </div>
  </div>

  <div id="modeName">Ładuję...</div>

  <div class="status">
    <div>Temp: <span id="tempValue">--</span>°C</div>
    <div>SOC: <span id="socValue">--</span>%</div>
  </div>

  <script>
    const slider = document.getElementById("modeSlider");
    const modeNameLabel = document.getElementById("modeName");

    slider.addEventListener("input", () => {
      const val = slider.value;
      fetch(`/setMode?mode=${val}`).catch(() => {});
    });

    function updateStatus() {
      fetch("/getTemp").then(r => r.text()).then(t => {
        document.getElementById("tempValue").textContent = t;
      }).catch(() => {});

      fetch("/getSOC").then(r => r.text()).then(s => {
        document.getElementById("socValue").textContent = s;
      }).catch(() => {});

      fetch("/getMode").then(r => r.text()).then(m => {
        slider.value = m;
      }).catch(() => {});
    }

    function updateModeName() {
      fetch("/getModeName").then(r => r.text()).then(name => {
        modeNameLabel.textContent = name;
      }).catch(() => {});
    }

    // Aktualizacja temp i SOC co 5s
    updateStatus();
    setInterval(updateStatus, 5000);

    // Aktualizacja nazwy trybu co 2s
    updateModeName();
    setInterval(updateModeName, 2000);
  </script>
</body>
</html>
)rawliteral";
