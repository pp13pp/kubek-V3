const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>ESP8266 LED Control</title>
  <style>
    body { font-family: sans-serif; background: #111; color: #eee; text-align: center; margin-top: 40px; }
    h2 { margin-bottom: 30px; }
    .slider { width: 80%%; }
    .label { margin-top: 10px; font-size: 1.2em; }
    .value { font-weight: bold; color: #0f0; }
  </style>
</head>
<body>
  <h2>ESP LED Controller</h2>

  <div>
    <p>Temperatura: <span id="temp" class="value">?</span> °C</p>
    <p>Stan naładowania (SOC): <span id="soc" class="value">?</span> %</p>
  </div>

  <div style="margin-top:40px;">
    <p>Tryb: <span id="modeLabel" class="value">?</span></p>
    <input type="range" min="0" max="10" class="slider" id="modeSlider" oninput="sendMode(this.value)">
    <div class="label">Wybór trybu: <span id="modeIndex">0</span></div>
  </div>

<script>
let modeNames = [
  "PACIFICA","RAINBOW","CYLON","LAVA","TWINKLE",
  "PULSEB","PULSEG","PULSER","FIRE","COLORWAVES","BUBBLES"
];

function updateTempSOC() {
  fetch('/getTemp').then(res => res.text()).then(t => {
    document.getElementById('temp').innerText = t;
  });
  fetch('/getSOC').then(res => res.text()).then(s => {
    document.getElementById('soc').innerText = s;
  });
}

function syncTimeWithESP() {
  let unixTime = Math.floor(Date.now() / 1000);
  fetch('/setTime?unix=' + unixTime);
}

function sendMode(val) {
  document.getElementById('modeIndex').innerText = val;
  document.getElementById('modeLabel').innerText = modeNames[val];
  fetch('/setMode?mode=' + val);
}

window.addEventListener('load', () => {
  updateTempSOC();
  syncTimeWithESP();
  document.getElementById('modeLabel').innerText = modeNames[0];
  setInterval(() => {
    updateTempSOC();
    syncTimeWithESP();
  }, 5000);
});
</script>
</body>
</html>
)rawliteral";
