const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>%TITLE%</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      text-align: center;
      margin: 0; padding: 20px;
      background-color: #111; color: #eee;
    }
    h1 {
      margin-top: 10px;
      font-size: 24px;
    }
    .slider-container {
      margin: 30px auto 10px;
      width: 90%;
      max-width: 600px;
      position: relative;
    }
    #modeSlider {
      -webkit-appearance: none;
      width: 100%;
      height: 50px;
      background: #333;
      border-radius: 12px;
      outline: none;
      cursor: pointer;
    }
    #modeSlider::-webkit-slider-thumb {
      -webkit-appearance: none;
      appearance: none;
      width: 40px;
      height: 50px;
      background: #0af;
      border-radius: 8px;
      cursor: pointer;
      margin-top: -9px;
      transition: background 0.3s ease;
    }
    #modeSlider::-moz-range-thumb {
      width: 40px;
      height: 50px;
      background: #0af;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    #modeSlider:hover::-webkit-slider-thumb {
      background: #08c;
    }
    .scale {
      display: flex;
      justify-content: space-between;
      position: absolute;
      top: 58px; /* poniżej suwaka */
      left: 0;
      right: 0;
      padding: 0 8px;
      font-size: 16px;
      color: #ccc;
      pointer-events: none;
      font-weight: bold;
      user-select: none;
    }
    #modeName {
      margin-top: 50px;
      font-weight: bold;
      font-size: 20px;
      color: #0af;
      min-height: 28px;
    }
    .status {
      margin-top: 25px;
      font-size: 18px;
    }
  </style>
</head>
<body>
  <h1>%TITLE%</h1>

  <div class="slider-container">
    <input type="range" min="0" max="12" value="0" id="modeSlider">
    <div class="scale">
      <span>0</span><span>2</span><span>4</span><span>6</span><span>8</span><span>10</span><span>12</span>
    </div>
  </div>

  <div id="modeName">Ładuję...</div>

  <div class="status">
    <div>Temp: <span id="tempValue">--</span>°C</div>
    <div>SOC: <span id="socValue">--</span>%</div>
  </div>

  <script>
    const slider = document.getElementById("modeSlider");
    const modeNameLabel = document.getElementById("modeName");

    slider.addEventListener("input", () => {
      const val = slider.value;
      fetch(`/setMode?mode=${val}`).catch(() => {});
    });

    function updateStatus() {
      fetch("/getTemp").then(r => r.text()).then(t => {
        document.getElementById("tempValue").textContent = t;
      }).catch(() => {});

      fetch("/getSOC").then(r => r.text()).then(s => {
        document.getElementById("socValue").textContent = s;
      }).catch(() => {});

      fetch("/getMode").then(r => r.text()).then(m => {
        slider.value = m;
      }).catch(() => {});
    }

    function updateModeName() {
      fetch("/getModeName").then(r => r.text()).then(name => {
        modeNameLabel.textContent = name;
      }).catch(() => {});
    }

    updateStatus();
    setInterval(updateStatus, 10000);
    updateModeName();
    setInterval(updateModeName, 2000);
  </script>
</body>
</html>
)rawliteral";
